#!/bin/sh
# ChatNest FC bootstrap v2 - deps bundled in /code/pylibs, no pip needed
exec 1>&2
echo "=== start.sh boot at $(date '+%F %T')"
PY=/usr/bin/python3
$PY --version
if [ ! -d /code/pylibs ]; then
  echo "FATAL: /code/pylibs missing"
  exit 1
fi
export PYTHONPATH=/code/pylibs:/code
echo "deps bundled, launching uvicorn..."
exec $PY -m uvicorn app:app --host 0.0.0.0 --port 9000 --app-dir /code
